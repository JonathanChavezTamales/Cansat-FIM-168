$(document).ready(function(){
$(function fadeInOut(){
$("#logo").fadeOut();{
$("#logo").fadeIn(1000, function () {
$("#logo").fadeOut(1000, function () {
$("#logo").fadeIn(1000, function () {
setTimeout(fadeInOut, 1000);
});
});
});
}
});

});