
$(document).ready(function(){
$(function fadeInOut(){
$("#logo2").fadeOut();{
$("#logo2").fadeIn(1000, function () {
$("#logo2").fadeOut(1000, function () {
$("#logo2").fadeIn(1000, function () {
setTimeout(fadeInOut, 1000);
});
});
});
}
});

});